//
//  AppRouter.swift
//  Fakestagram
//
//  Created by Grecia Escárcega on 04/06/24.
//

import UIKit

struct AppRouter {

    
}
