//
//  ViewController.swift
//  ShoppingList
//
//  Created by Marco Antonio Alvarado Díaz on 17/05/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TextField: UITextField!{
        didSet{
            TextField.inputAccessoryView = toolBar
        }
    }
    @IBOutlet weak var tableView: UITableView!
    var shoppingList = ["Huevos", "Frijoles", "Tortillas"]
    //let arrayTwo = ["cuatro", "cinco", "seis", "siete"]
    override func viewDidLoad() {
        super.viewDidLoad()
        //Protocolos y delegados, quién va a hacer toda la acción de quien esté implementando el delegado.
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        // Do any additional setup after loading the view.
    }
    
    lazy var toolBar: UIToolbar = {
        let tool: UIToolbar = .init(frame: .init(x: 0, y:0, width:UIScreen.main.bounds . width, height: 50))
        tool.barStyle = .default
        tool.isTranslucent = false
        tool.tintColor = .blue
        tool.sizeToFit()
        let spaceArea: UIBarButtonItem = .init(systemItem: .flexibleSpace)
        let doneButton: UIBarButtonItem = .init(title: "Done", style: .done, target: self, action: #selector (dismissKeyboard))
        tool.setItems([spaceArea, doneButton], animated: false)
        tool.isUserInteractionEnabled = true
        return tool
    }()
    
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    
    @IBAction func addButton(_ sender: Any){
        shoppingList.append(TextField.text ?? "")
        tableView.reloadData()
    }
}

extension ViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    //Header in section
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        "Shopping List 🛒"
    }
    
    //Mínimo necesario para poder empezar a manejar una tabla
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if section == 0{
//            arrayTwo.count
//        } else{
            shoppingList.count
//        }
    }
    
    //Configurar la o las celdas.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //MARK: - Celda no reutilizable
        //Identificadores de la celda, cuidado porque si no coincide, ya es otra persona.
//        var cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
//        cell.textLabel?.text="Holi"
//        cell.detailTextLabel?.text=" a todos"
        
        //MARK: - Celda reutilizable con un solo Juan
//        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
//
//        if cell == nil{
//            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
//            cell?.backgroundColor = .gray
//            cell?.accessoryType = .disclosureIndicator
//        }
//        //Para ya no usar textLabel
//        if #available(iOS 14, *){
//            var content = cell?.defaultContentConfiguration()
//            content?.text = array[indexPath.row]
//            //content?.secondaryText = "a todos"
//            cell?.contentConfiguration = content
//        }else{
//            cell?.textLabel?.text="Holi"
//        }
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? CustomTableViewCell
        
        //if indexPath.section == 0{
            //cell?.CellTextLabel.text = arrayTwo[indexPath.row]
        //} else{
        cell?.CellTextLabel.text = shoppingList[indexPath.row]
        //}
        //
        return cell!
    }
    
    
}


extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            70
        } else{
            50
        }
    }
    
    //Función para ir a otras ventanas
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Como seleccionar para hacer X acción
        //print(array[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let alertController = UIAlertController(title: "Are you sure to delete: " + shoppingList[indexPath.row], message: nil, preferredStyle: .alert)
            let confirmAction = UIAlertAction(title: "Confirm", style: .default) { _ in
                print("Alert controller dismissed")
                self.shoppingList.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
            let dismissAction = UIAlertAction(title: "Return", style: .destructive) { _ in
                print("Alert controller dismissed")
            }
            alertController.addAction(confirmAction)
            alertController.addAction(dismissAction)
            present(alertController, animated: true)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
}


extension ViewController: UITextFieldDelegate{
    
}
