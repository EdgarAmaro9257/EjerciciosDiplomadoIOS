//
//  TableViewCell_Type.swift
//  Pokedex
//
//  Created by Ana Paula Flores on 13/11/23.
//

import Foundation
import UIKit
class TableViewCell_Type : UITableViewCell{
    @IBOutlet weak var elementoimage: UIImageView!
    @IBOutlet weak var tipoelemento: UILabel!
    
    
    
}
