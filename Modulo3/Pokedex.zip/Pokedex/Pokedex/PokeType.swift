//
//  PokeType.swift
//  Pokedex
//
//  Created by Ana Paula Flores on 13/11/23.
//

import Foundation
class PokeType{
    var elemento : String!
    var imageElemento : String!
    
    public init(elemento: String, imageElemento: String){
        self.elemento = elemento
        self.imageElemento = imageElemento
    }
}
