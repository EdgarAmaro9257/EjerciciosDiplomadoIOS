//
//  CellcollecttionViewType.swift
//  Pokedex
//
//  Created by Diplomado on 31/05/24.
//

import Foundation
import UIKit
class CellcollecttionViewType : UICollectionViewCell{
    
    @IBOutlet weak var imagenelemento: UIImageView!
    
    
    
}
