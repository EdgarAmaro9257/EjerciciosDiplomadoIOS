//
//  Tipo.swift
//  Pokedex
//
//  Created by Diplomado on 31/05/24.
//

import Foundation
import UIKit
class Tpo : UIViewController{
    
    @IBOutlet weak var imgenagua: UIImageView!
    @IBOutlet weak var imagenfuego: UIImageView!
    @IBOutlet weak var imagenplanta: UIImageView!
    @IBOutlet weak var imagenrayo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
