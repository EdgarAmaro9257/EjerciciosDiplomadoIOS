import Foundation
import UIKit
class TableViewCell : UITableViewCell{
 
    @IBOutlet weak var nombrepoke: UILabel!
    @IBOutlet weak var imagepoke: UIImageView!
}
