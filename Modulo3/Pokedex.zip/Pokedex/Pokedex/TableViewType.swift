//
//  TableViewType.swift
//  Pokedex
//
//  Created by Ana Paula Flores on 13/11/23.
//

import Foundation
import UIKit
class TableViewType: UIViewController{
    
//    @IBOutlet weak var tipoelementoL: UILabel!
//    @IBOutlet weak var elemento: UIImageView!
}
