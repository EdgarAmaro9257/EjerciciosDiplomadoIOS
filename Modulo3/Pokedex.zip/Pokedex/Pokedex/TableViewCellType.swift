//
//  TableViewCellType.swift
//  Pokedex
//
//  Created by Ana Paula Flores on 13/11/23.
//

import Foundation
import UIKit
class TableViewCellType : UITableViewCell{
 
    @IBOutlet weak var imageElemento: UIImageView!
    @IBOutlet weak var elemento: UILabel!
}
