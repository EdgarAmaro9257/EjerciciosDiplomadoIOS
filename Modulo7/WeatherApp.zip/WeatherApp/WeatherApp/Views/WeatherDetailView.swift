//
//  WeatherDetailView.swift
//  WeatherApp
//
//  Created by Diplomado on 03/08/24.
//

import SwiftUI
import MapKit

struct WeatherDetailView: View {
    @State private var weather: Weather?
    @State private var isFavorite = false
    let location: Location
    @StateObject private var viewModel = WeatherDetailViewModel()

    var body: some View {
        VStack {
            if let weather = weather {
                Text(location.nombre)
                    .font(.title)
                Text("País: \(weather.location.country)")
                Text("Hora Local: \(formatDate(weather.location.localtime))")
                Text("Última Actualización: \(formatDate(weather.current.condition.text))")
                
                Picker("Temperatura", selection: $viewModel.unit) {
                    Text("Celsius").tag(TemperatureUnit.celsius)
                    Text("Fahrenheit").tag(TemperatureUnit.fahrenheit)
                }
                .pickerStyle(SegmentedPickerStyle())
                
                Text("Temperatura: \(viewModel.convertTemperature(weather))")
                Text("Índice UV: \(weather.current.uv)")
                Map(coordinateRegion: $viewModel.region, annotationItems: [weather.location]) { location in
                    MapPin(coordinate: CLLocationCoordinate2D(latitude: location.lat, longitude: location.lon), tint: .blue)
                }
                Image(uiImage: UIImage(systemName: weather.current.condition.icon) ?? UIImage())
                
                Button(action: toggleFavorite) {
                    Image(systemName: isFavorite ? "star.fill" : "star")
                }
            } else {
                ProgressView()
            }
        }
        .onAppear(perform: loadWeather)
    }

    private func formatDate(_ dateString: String) -> String {
        // Formatear la cadena de fecha
        return dateString
    }

    private func loadWeather() {
        NetworkManager.shared.fetchWeather(for: location.nombre) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let weatherData):
                    self.weather = weatherData
                    isFavorite = UserDefaultsManager().getFavorites().contains(where: { $0.id == location.id })
                    viewModel.region = MKCoordinateRegion(
                        center: CLLocationCoordinate2D(latitude: weatherData.location.lat, longitude: weatherData.location.lon),
                        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                    )
                case .failure(let error):
                    print("Error al obtener el clima: \(error)")
                }
            }
        }
    }

    private func toggleFavorite() {
        let userDefaultsManager = UserDefaultsManager()
        if isFavorite {
            userDefaultsManager.removeFavorite(location: location)
        } else {
            userDefaultsManager.saveFavorite(location: location)
        }
        isFavorite.toggle()
    }
}




