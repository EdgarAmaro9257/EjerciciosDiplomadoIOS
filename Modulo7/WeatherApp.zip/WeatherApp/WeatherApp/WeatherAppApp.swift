//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Diplomado on 03/08/24.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
