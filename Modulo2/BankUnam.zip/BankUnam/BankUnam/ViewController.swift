//
//  ViewController.swift
//  BankUnam
//
//  Created by Diplomado on 22/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

